MMDS book: http://infolab.stanford.edu/~ullman/mmds/book.pdf

Mandatory readings (chapters from MMDS book):

1.3.1 Importance of Words in Documents (page 8-9)

3.1 Finding Similar Items - Applications of Near-Neighbor Search  (page 73-77)

7.3 K-means algorithms (page 254-257)

The mandatory readings give us necessary ingredients building up to a simple example for a system we will walk through in class. For those seeking an extra challenge, the optional readings provide more context and a view into a more sophisticated content representation technique commonly known as word2vec, a precursor to contextual embeddings used in modern LLMs. 

Optional readings:

The rest of 7.3 K-means algorithms (page 257-262)
9.1 A model for recommendation systems (page 307-311)
9.2 Content-based recommendations (page 311-320)
Distributed Representations of Words and Phrases and their Compositionality. Mikolov et al., 2013. (word2vec) 
a more accessible blogpost explaning word2vec